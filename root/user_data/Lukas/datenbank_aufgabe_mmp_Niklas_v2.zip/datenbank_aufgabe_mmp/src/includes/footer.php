    </main>
    <footer>
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> MMP Lernplattform - Gemeinsam Lernen & Arbeiten</p>
        </div>
    </footer>
</body>
</html>
